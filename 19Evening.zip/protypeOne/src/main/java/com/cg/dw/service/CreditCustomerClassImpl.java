package com.cg.dw.service;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dw.dao.CaseIdDao;
import com.cg.dw.dao.CreditCardDao;
import com.cg.dw.dao.CreditCardTransactionDao;
import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.model.CreditCardBean;
import com.cg.dw.model.CreditCardTransaction;
import com.cg.dw.model.CustomerBean;

@Service
public class CreditCustomerClassImpl implements CreditCustomer {
	// private static Logger logger =
	// Logger.getLogger(CreditCustomerClassImpl.class);
	@Autowired
	private CaseIdDao caseIdDao;

	@Autowired
	private CreditCardTransactionDao creditCardTransactionDao;
	@Autowired
	private CreditCardDao creditCardDao;

	String caseIdGenOne = " ";
	static String caseIdTotal = " ";
	static int caseIdGenTwo = 0;
	LocalDateTime timestamp;
	LocalDateTime fromDate;
	LocalDateTime toDate;
	static String setCardType = null;
	static String uniqueID = null;
	static String customerReferenceID = null;
	Random random = new Random();

	@Override
	public String addToServiceRequestTable(String caseIdGenOne) {
		// logger.info("entered into addToServiceRequestTable method of
		// CustomerServiceImpl class");
		Date dNow = new Date();
		SimpleDateFormat ftDateFormat = new SimpleDateFormat("yyMMddhhmmssS");
		String dateString = ftDateFormat.format(dNow);

		caseIdTotal = caseIdGenOne + dateString;

		return caseIdTotal;
	}

	@Transactional
	@Override
	public String requestCreditCardUpgrade(BigInteger creditCardNumber, String myChoice, String remarks)
			throws IBSException {
		// logger.info("entered into requestCreditCardUpgrade method of
		// CreditCustomerClassImpl class");
		String status = creditCardDao.getCreditCardStatus(creditCardNumber);

		if (status.equals("Blocked")) {
			throw new IBSException(ErrorMessages.CARD_BLOCK_MESSAGE);
		} else {
			CaseIdBean caseIdObj = new CaseIdBean();
			caseIdGenOne = "RCCU";
			timestamp = LocalDateTime.now();

			caseIdTotal = addToServiceRequestTable(caseIdGenOne);
			customerReferenceID = (caseIdTotal + random.nextInt(100));
			caseIdObj.setCaseIdTotal(caseIdTotal);
			caseIdObj.setCaseTimeStamp(timestamp);
			caseIdObj.setRequestMap("RCCU");
			caseIdObj.setStatusOfServiceRequest("Pending");
			caseIdObj.setCardNumber(creditCardNumber);
			caseIdObj.setCustomerRemarks(remarks);
			CustomerBean custom = new CustomerBean();
			custom.setUCI(creditCardDao.getCreditUci(creditCardNumber));
			caseIdObj.setCustomerBeanObject(custom);
			caseIdObj.setDefineServiceRequest(myChoice);
			caseIdObj.setCustomerReferenceId(customerReferenceID);
			caseIdDao.actionServiceRequest(caseIdObj);
			return customerReferenceID;

		}

	}

	@Transactional
	@Override
	public void resetCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
		// logger.info("entered into resetCreditPin method of
		// CreditCustomerClassImpl class");
		try {

			creditCardDao.setNewCreditPin(creditCardNumber, newPin);

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

	@Override
	public List<CreditCardBean> getUnblockedCreditCards() throws IBSException {
		try {
			return creditCardDao.viewAllUnblockedCreditCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	@Transactional
	@Override
	public String applyNewCreditCard(String newCardType, BigInteger uci) throws IBSException {
		// logger.info("entered into applyNewCreditCard method of
		// CreditCustomerClassImpl class");

		CaseIdBean caseIdObj = new CaseIdBean();
		caseIdGenOne = "ANCC";
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		timestamp = LocalDateTime.now();

		caseIdObj.setCaseTimeStamp(timestamp);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setRequestMap("ANCC");
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setDefineServiceRequest(newCardType);

		CustomerBean custom = new CustomerBean();
		custom.setUCI(uci);
		caseIdObj.setCustomerBeanObject(custom);

		try {

			caseIdDao.actionServiceRequest(caseIdObj);

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return customerReferenceID;
	}

	@Transactional
	@Override

	public void requestCreditCardLost(BigInteger creditCardNumber) throws IBSException {

		try {

			creditCardDao.blockCreditCard(creditCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Transactional
	@Override
	public String raiseCreditMismatchTicket(BigInteger transactionId, String remarks) throws IBSException {
		// logger.info("entered into raiseCreditMismatchTicket method of
		// CreditCustomerClassImpl class");

		caseIdGenOne = "RCMT";
		CaseIdBean caseIdObj = new CaseIdBean();
		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");

		CustomerBean custom = new CustomerBean();
		custom.setUCI(creditCardTransactionDao.getCMUci(transactionId));
		caseIdObj.setCustomerBeanObject(custom);

		caseIdObj.setDefineServiceRequest(transactionId.toString());
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setCardNumber(creditCardTransactionDao.getCreditCardNumber(transactionId));
		caseIdObj.setCustomerRemarks(remarks);
		caseIdObj.setRequestMap("RCMT");

		try {

			caseIdDao.actionServiceRequest(caseIdObj);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}
		return (customerReferenceID);

	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(LocalDate startDate1, LocalDate endDate1,
			BigInteger creditCardNumber) throws IBSException {

		List<CreditCardTransaction> creditCardBeanTrns = null;

		if (!Period.between(startDate1, endDate1).isNegative()) {
			try {

				creditCardBeanTrns = creditCardTransactionDao.getCreditTrans(startDate1, endDate1, creditCardNumber);

			} catch (IBSException e) {

				throw new IBSException(e.getMessage());
			}
		} else
			throw new IBSException(ErrorMessages.DATES_CHRONOLOGICALLY_INCORRECT);

		return creditCardBeanTrns;
	}

	@Override
	public List<CreditCardBean> viewAllCreditCards() throws IBSException {

		List<CreditCardBean> list = null;
		try {
			list = creditCardDao.viewAllCreditCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return list;
	}

	@Override
	@Transactional
	public void activateCreditCard(BigInteger creditCardNumber) throws IBSException {

		try {

			creditCardDao.activateCreditCard(creditCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	@Transactional
	public void deactivateCreditCard(BigInteger creditCardNumber) throws IBSException {

		try {

			creditCardDao.deactivateCreditCard(creditCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public List<CreditCardBean> getInactiveCreditCards() throws IBSException {
		try {
			return creditCardDao.viewAllInactiveCreditCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

	@Override
	public boolean getCreditTransactions(BigInteger creditCardNumber) throws IBSException {
		boolean result = false;
		if (creditCardTransactionDao.checkTransactions(creditCardNumber)) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean checkCreditCardCount() throws IBSException {
		boolean check = true;
		try {
			List<CreditCardBean> credList = creditCardDao.viewAllUnblockedCreditCards();
			if (credList.size() == 1)
				check = false;
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
		return check;

	}

	@Override
	public CreditCardBean fetchCreditdetails(BigInteger creditCard) throws IBSException {
		try {
			return creditCardDao.getCreditdetails(creditCard);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

	@Override
	public String getCreditcardStatus(BigInteger creditCard) throws IBSException {
		String status;

		try {
			status = creditCardDao.getCreditCardStatus(creditCard);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return status;
	}

	@Override
	public String getCreditcardType(BigInteger creditCard) throws IBSException {
		String type;

		try {
			type = creditCardDao.getcreditCardType(creditCard);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return type;
	}

}
