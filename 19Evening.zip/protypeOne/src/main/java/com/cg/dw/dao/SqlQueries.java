package com.cg.dw.dao;

public class SqlQueries {

	public static final String SELECT_DATA_FROM_CREDIT_CARD = "select c from CreditCardBean c";
	public static final String SELECT_DATA_FROM_DEBIT_CARD = "select d from DebitCardBean d";

	public static final String VERIFY_DEBIT_CARD_NUM = "Select d from DebitCardBean d  where d.debitCardNumber=?1";

	public static final String SELECT_DATA_FROM_SERVICE_REQUEST = "Select d from CaseIdBean d where d.statusOfServiceRequest not in ('Approved') and d.statusOfServiceRequest not in ('Disapproved')";
	public static final String SELECT_FROM_DEBIT_CARD ="select d from DebitCardBean d where d.cardStatus  IN (:num)";
	public static final String SELECT_DATA_FROM_ACCOUNT = "select a from AccountBean a";
	public static final String SELECT_FROM_CREDIT_CARDS = "select d from CreditCardBean d where d.cardStatus IN (:num)";
	public static final String SELECT_DATA_FROM_SERVICE_REQUEST_FOR_NEW_DEBIT = "select c from CaseIdBean c where c.requestMap='ANDC' AND statusOfServiceRequest in ('Pending')";
	public static final String SELECT_DATA_FROM_SERVICE_REQUEST_FOR_NEW_CREDIT = "select c from CaseIdBean c where c.requestMap='ANCC' AND statusOfServiceRequest in ('Pending')";
	public static final String SELECT_DATA_FROM_SERVICE_REQUEST_FOR_DEBIT_UPGRADE = "select c from CaseIdBean c where c.requestMap='RDCU' AND statusOfServiceRequest in ('Pending')";
	public static final String SELECT_DATA_FROM_SERVICE_REQUEST_FOR_CREDIT_UPGRADE = "select c from CaseIdBean c where c.requestMap='RCCU' AND statusOfServiceRequest in ('Pending')";
	public static final String SELECT_DATA_FROM_SERVICE_REQUEST_FOR_DEBIT_MISMATCH = "select c from CaseIdBean c where c.requestMap='RDMT' AND statusOfServiceRequest in ('Pending')";
	public static final String SELECT_DATA_FROM_SERVICE_REQUEST_FOR_CREDIT_MISMATCH = "select c from CaseIdBean c where c.requestMap='RCMT' AND statusOfServiceRequest in ('Pending')";
	public static final String SELECT_DATA_FROM_SERVICE_REQUESTS = "select c from CaseIdBean c";

}